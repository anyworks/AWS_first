# AWS_first

If you using the NODIST then launch the command of following ahead.

    npm config set prefix "%NODIST_PREFIX%\bin"
    
    
